import React from "react";

const ReportPage = () => {
  return <div>ReportPage</div>;
};

export default ReportPage;
