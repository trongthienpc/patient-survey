import React from "react";
import Lottie from "lottie-react";
import Party from "@/data/animations/party.json";
const ThankYouPage = () => {
  return (
    <div className="flex flex-col items-center justify-center h-full gap-6">
      <div className="text-center flex-col justify-center items-center">
        <h2 className="text-2xl font-bold">
          Phương Châu xin cảm ơn Quý khách đã tin tưởng và để lại những chia sẻ
          về chất lượng trải nghiệm dành cho chúng tôi
        </h2>
        <p className="mt-2">Kính chúc Quý khách nhiều sức khỏe!</p>
      </div>
      <div>
        <Lottie
          animationData={Party}
          loop={true}
          style={{ width: 100, height: 100 }}
        />
      </div>
    </div>
  );
};

export default ThankYouPage;
