import SurveyForm from "@/components/SurveyForm";
import { BackgroundGradientAnimation } from "@/components/ui/background-gradient-animation";

export default function Home() {
  return (
    <div className="w-full h-screen relative" style={{}}>
      <BackgroundGradientAnimation />
      <div className="absolute inset-0 flex items-center justify-center px-4 z-50">
        <div className="pointer-events-auto w-full mx-auto max-w-3xl">
          <SurveyForm />
        </div>
      </div>
    </div>
  );
}
