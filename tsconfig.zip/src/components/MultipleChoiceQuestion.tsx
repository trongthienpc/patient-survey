import { useEffect, useState } from "react";
import Lottie from "lottie-react";
import { Button } from "./ui/button";
interface QuestionProps {
  key: number;
  value: string;
  iconPath: string;
}

interface MultipleChoiceQuestionProps {
  question: string;
  options: QuestionProps[];
  onAnswerChange: (answers: number[]) => void;
  initialAnswer: number[];
}
const MultipleChoiceQuestion = ({
  question,
  options,
  onAnswerChange,
  initialAnswer,
}: MultipleChoiceQuestionProps) => {
  const [selectedOptions, setSelectedOptions] = useState<number[]>(
    initialAnswer || []
  );

  useEffect(() => {
    setSelectedOptions(initialAnswer || []);
  }, [initialAnswer]);

  const toggleOption = (option: number) => {
    const updatedOptions = selectedOptions.includes(option)
      ? selectedOptions.filter((item) => item !== option)
      : [...selectedOptions, option];
    setSelectedOptions(updatedOptions);
    onAnswerChange(updatedOptions);
  };

  return (
    <div className="my-4">
      <p className="mb-3">{question}</p>
      <div className="flex flex-col gap-3 px-3">
        {options.map((option, index) => (
          <div className="flex items-center space-x-2" key={index}>
            <Button
              variant={
                selectedOptions.includes(option.key) ? "default" : "outline"
              }
              onClick={() => toggleOption(option.key)}
              className="flex items-center justify-start space-x-2 text-wrap text-left px-3 py-4 h-16"
            >
              <Lottie
                animationData={option.iconPath}
                loop={true}
                style={{ width: "30px", height: "30px" }}
              />
              <span>{option.value}</span>
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MultipleChoiceQuestion;
