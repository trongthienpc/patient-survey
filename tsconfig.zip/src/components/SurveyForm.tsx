"use client";

import SatisfactionRating from "@/components/SatisfactionRating";
import MultipleChoiceQuestion from "@/components/MultipleChoiceQuestion";
import { useState } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import ThankYouPage from "@/app/thank-you/page";
import { CardContent, CardDescription } from "@/components/ui/card";
import {
  dissatisfiedWithExamination,
  satisfiedWithExamination,
} from "@/data/questions";
import {
  CardBody,
  CardContainer,
  CardItem,
} from "@/components/aceternity-ui/3d-card";
const sections = [
  { name: "Bác sĩ khám", id: "Bác sĩ khám" },
  { name: "Bác sĩ siêu âm", id: "Bác sĩ siêu âm" },
  { name: "Nhân viên CSKH", id: "Nhân viên CSKH" },
];

const SurveyForm = () => {
  const [selectedSections, setSelectedSections] = useState<string[]>([]);
  const [currentSectionIndex, setCurrentSectionIndex] = useState(0);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [isStarted, setIsStarted] = useState(false);
  const [answers, setAnswers] = useState<{ [key: string]: any }>({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSectionToggle = (sectionId: string) => {
    setSelectedSections((prev) =>
      prev.includes(sectionId)
        ? prev.filter((s) => s !== sectionId)
        : [...prev, sectionId]
    );
  };

  const handleStart = () => {
    setIsStarted(true);
  };

  const handleAnswerChange = (questionId: string, answer: any) => {
    setAnswers((prev) => ({ ...prev, [questionId]: answer }));
  };

  const handleNext = () => {
    console.log("Next");
    const section = selectedSections[currentSectionIndex];
    const questionId = `${section}-${currentQuestionIndex}`;
    if (!answers[questionId]) {
      alert("Please answer the current question before proceeding.");
      return;
    }

    if (currentQuestionIndex < 2) {
      setCurrentQuestionIndex((prev) => prev + 1);
    } else if (currentSectionIndex < selectedSections.length - 1) {
      setCurrentSectionIndex((prev) => prev + 1);
      setCurrentQuestionIndex(0);
    }
  };

  const handleBack = () => {
    console.log("Back");
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex((prev) => prev - 1);
    } else if (currentSectionIndex > 0) {
      setCurrentSectionIndex((prev) => prev - 1);
      setCurrentQuestionIndex(2);
    }
  };

  const handleSubmit = () => {
    const unansweredQuestion = selectedSections.some((sectionId) =>
      [0, 1, 2].some(
        (questionIndex) => !answers[`${sectionId}-${questionIndex}`]
      )
    );

    if (unansweredQuestion) {
      alert("Please answer all questions before submitting.");
    } else {
      console.log("Survey submitted:", answers);
      setIsSubmitted(true);
    }
  };

  const renderQuestion = () => {
    const section = selectedSections[currentSectionIndex];
    const questionId = `${section}-${currentQuestionIndex}`;
    const currentAnswer = answers[questionId];
    const questions = [
      <SatisfactionRating
        key="satisfaction"
        question={`Bạn hài lòng thế nào với ${section}?`}
        initialAnswer={currentAnswer}
        onAnswerChange={(answer) => handleAnswerChange(questionId, answer)}
      />,
      <MultipleChoiceQuestion
        key="dissatisfied"
        question="Bạn không hài lòng điều gì về nhân viên vừa rồi?"
        options={dissatisfiedWithExamination}
        initialAnswer={currentAnswer}
        onAnswerChange={(answer) => handleAnswerChange(questionId, answer)}
      />,
      <MultipleChoiceQuestion
        key="satisfied"
        question="Bạn hài lòng điều gì về nhân viên vừa rồi?"
        options={satisfiedWithExamination}
        initialAnswer={currentAnswer}
        onAnswerChange={(answer) => handleAnswerChange(questionId, answer)}
      />,
    ];
    return questions[currentQuestionIndex];
  };

  return (
    <CardContainer className="inter-var select-none w-full max-w-4xl border border-dashed rounded-xl border-violet-500">
      <CardBody className="bg-gray-50 relative group/card  dark:hover:shadow-2xl dark:hover:shadow-emerald-500/[0.1] dark:bg-black dark:border-white/[0.2] border-black/[0.1] w-full max-w-4xl  h-auto rounded-xl p-6 border  ">
        <CardItem
          translateZ="0"
          className="text-2xl font-bold text-neutral-600 dark:text-white"
        >
          Khảo sát độ hài lòng khách hàng
        </CardItem>
        <CardItem
          as="p"
          translateZ="0"
          className="text-neutral-800 text-sm mt-2 dark:text-neutral-300"
        >
          Nhằm cải thiện chất lượng sản phẩm, dịch vụ và trải nghiệm khách hàng
        </CardItem>
        <CardItem translateZ="0" className="w-full mt-3 select-none">
          {!isStarted ? (
            <div className="w-full">
              <CardDescription>Chọn nội dung cần đánh giá:</CardDescription>
              <CardContent className="">
                {sections.map((section) => (
                  <div
                    className="flex items-center space-x-2 space-y-2 select-none"
                    key={section.id}
                  >
                    <Checkbox
                      id={section.id}
                      checked={selectedSections.includes(section.id)}
                      onCheckedChange={() => handleSectionToggle(section.id)}
                    />
                    <label
                      htmlFor={section.id}
                      className="text-sm font-medium "
                    >
                      <span>{section.name}</span>
                    </label>
                  </div>
                ))}
              </CardContent>
              <CardItem translateZ={50}>
                <Button
                  onClick={handleStart}
                  disabled={selectedSections.length === 0}
                >
                  Start
                </Button>
              </CardItem>
            </div>
          ) : isSubmitted ? (
            <ThankYouPage />
          ) : (
            <div>
              {renderQuestion()}
              <div className="flex justify-between mt-4">
                <Button
                  className="select-none"
                  onClick={handleBack}
                  disabled={
                    currentQuestionIndex === 0 && currentSectionIndex === 0
                  }
                >
                  Back
                </Button>
                {currentSectionIndex === selectedSections.length - 1 &&
                currentQuestionIndex === 2 ? (
                  <Button className="select-none" onClick={handleSubmit}>
                    Submit
                  </Button>
                ) : (
                  <Button className="select-none" onClick={handleNext}>
                    Next
                  </Button>
                )}
              </div>
            </div>
          )}
        </CardItem>
      </CardBody>
    </CardContainer>
  );
};

export default SurveyForm;
