"use client";

import { useEffect, useState } from "react";
import Lottie from "lottie-react";
import angryAnimation from "@/data/animations/angry.json";
import sadAnimation from "@/data/animations/sad.json";
import mehAnimation from "@/data/animations/normal.json";
import happyAnimation from "@/data/animations/happy.json";
import veryHappyAnimation from "@/data/animations/supprise.json";
interface SatisfactionRatingProps {
  question: string;
  initialAnswer: number | null;
  onAnswerChange: (answer: number) => void;
}

const SatisfactionRating = ({
  question,
  onAnswerChange,
  initialAnswer,
}: SatisfactionRatingProps) => {
  const [rating, setRating] = useState<number | null>(null);

  useEffect(() => {
    setRating(initialAnswer);
  }, [initialAnswer]);

  const ratings = [
    {
      level: 1,
      animationData: angryAnimation,
      label: "Rất không hài lòng",
    },
    {
      level: 2,
      animationData: sadAnimation,
      label: "Không hài lòng",
    },
    {
      level: 3,
      animationData: mehAnimation,
      label: "Bình thường",
    },
    {
      level: 4,
      animationData: happyAnimation,
      label: "Hài lòng",
    },
    {
      level: 5,
      animationData: veryHappyAnimation,
      label: "Rất hài lòng",
    },
  ];

  const handleRatingChange = (level: number) => {
    setRating(level);
    onAnswerChange(level);
  };

  return (
    <div className="my-4">
      <h2 className="text-xl font-bold">{question}</h2>{" "}
      {/* Tiêu đề cho câu hỏi */}
      <div className="flex space-x-2 mt-2">
        {ratings.map(({ level, animationData, label }) => (
          <button
            key={level}
            className={`p-2 rounded-full flex flex-col items-center ${
              rating === level ? "bg-gray-200" : ""
            }`}
            onClick={() => handleRatingChange(level)}
          >
            <Lottie animationData={animationData} />
            <div className="text-center mt-2">{label}</div>{" "}
            {/* Hiển thị nhãn cho mức đánh giá */}
          </button>
        ))}
      </div>
    </div>
  );
};

export default SatisfactionRating;
